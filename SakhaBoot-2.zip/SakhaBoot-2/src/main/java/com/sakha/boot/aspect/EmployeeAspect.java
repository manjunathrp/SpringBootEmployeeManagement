package com.sakha.boot.aspect;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class EmployeeAspect {
	
	@Pointcut("within(com.sakha.boot.service.EmployeeService)")
	public void op() {}
	
	/*
	 * @Before("execution(* com.sakha.boot.service.EmployeeService.delete(*))")
	 * public void beforeDeleteAdvice() { System.out.println("Deleting ......"); }
	 */
	
	@Before("op()")
	public void showLog()
	{
	    System.out.println("Transaction started...");
	}
	
	@AfterReturning("op()")
	public void afterDeteteAdvice()
	{
		System.out.println("Transaction successfull...");
	}
	
	@AfterThrowing("op()")
	public void afterFailure() {
		System.out.println("Transaction failure....");
	}

}
