package com.sakha.boot.controller;

//import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
//simport org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sakha.boot.model.Employee;
import com.sakha.boot.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeController {
	@Autowired
	EmployeeService service;
	
	@GetMapping("/employees")
	public List<Employee> getAllEmployees() throws Exception{

	return service.getAllEmployee();
	}
	@GetMapping("/employees/{empId}")
	public Employee getEmployee(@PathVariable("empId") int empId) throws Exception
	{
	return service.getEmployee(empId);
	}

	@PostMapping("/employees")
	public Employee saveEmployee(@RequestBody Employee emp)throws Exception
	{
	return service.registerEmp(emp);
	}
	
	@DeleteMapping("/employee/{empId}")
    public boolean deleteEmployee(@PathVariable("empId") String empId) throws Exception
    
    {
        return service.delete(empId);
    }
    @PutMapping("/employee")
    
        public Boolean updateEmployee(@RequestBody Employee emp) throws Exception
        {
        return service.update(emp);
    }
	
	/*
	 * @GetMapping({"/"}) public String defaultPage() { return "home"; }
	 * 
	 * @PostMapping("/employee") public String save(@ModelAttribute Employee emp,
	 * Model m) { m.addAttribute("emp",service.registerEmp(emp)); return "view"; }
	 * 
	 * @PostMapping("/employees") public String update(@RequestParam("empName")
	 * String empName,@RequestParam("salary") float salary,@RequestParam("dob")
	 * LocalDate dob, Model m) { Employee emp = new Employee();
	 * emp.setEmpName(empName); emp.setSalary(salary); emp.setDob(dob);
	 * m.addAttribute("emp",service.registerEmp(emp)); return "view"; }
	 * 
	 * 
	 * @PostMapping("/employeeUpdate") public String updateEmp(@ModelAttribute
	 * Employee emp, Model m) { System.out.println(emp);
	 * m.addAttribute("emp",service.updateEmp(emp)); return "viewEmployee"; }
	 * 
	 * @PostMapping("/getByEmployeeId") public String
	 * getEmployeebyId(@RequestParam("empId") String empId, Model m) {
	 * 
	 * m.addAttribute("emp",service.getByEmpId(empId)); return "viewEmployee"; }
	 * 
	 * @PostMapping("/deleteEmp") public String
	 * deleteEmployee(@RequestParam("empId") Integer empId, Model m) { //Integer emp
	 * = empId; service.deleteEmployee(empId); m.addAttribute("success",
	 * "successfull"); return "delete"; }
	 * 
	 * @GetMapping("/getAll") public String getAllEmpl(Model m) {
	 * m.addAttribute("allEmp", service.getAllEmployee()); return "viewAllEmployee";
	 * }
	 * 
	 * @PostMapping("/getByEmployeeId1") public String
	 * getEmployeebyId1(@RequestParam("empId") String empId, Model m) {
	 * 
	 * m.addAttribute("emp",service.getByEmpId(empId)); return
	 * "viewEmployeeToUpdate"; }
	 */
	

}
